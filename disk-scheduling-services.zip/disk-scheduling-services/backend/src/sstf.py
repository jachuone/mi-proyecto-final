def sstf(arm_position, lrequests, debug=False):
    """
    Shortest Seek Time First (SSTF) implementation.

    Args:
        arm_position (int): Initial position of the arm.
        lrequests (list<int>): List of track requests.
        debug (bool): If True, prints debug information.

    Returns:
        dict: Contains the seek sequence, total distance, and average seek length.
    """
    distance = 0
    current_pos = arm_position
    sequence = []
    requests = lrequests[:]  # Copiar la lista de solicitudes para modificarla

    while requests:
        # Encontrar la solicitud más cercana a la posición actual
        closest_request = min(requests, key=lambda x: abs(x - current_pos))
        distance += abs(closest_request - current_pos)
        current_pos = closest_request
        sequence.append(closest_request)
        requests.remove(closest_request)  # Eliminar la solicitud atendida

        if debug:
            print(f"Atendiendo {closest_request}, posición actual: {current_pos}, distancia acumulada: {distance}")

    average = distance / len(lrequests)

    return {
        "sequence": [arm_position] + sequence,
        "distance": distance,
        "average": average,
    }


# Prueba del algoritmo SSTF
result = sstf(96, [125, 17, 23, 67, 90, 128, 189, 115, 97], debug=True)
print(f"\nSecuencia de movimientos: {result['sequence']}")
print(f"Distancia total recorrida: {result['distance']}")
print(f"Promedio de distancias: {result['average']:.2f}")
