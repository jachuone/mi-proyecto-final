def clook(arm_position, lrequests, debug=False):
    """
    Circular LOOK implementation.

    Args:
        arm_position (int): Initial arm position.
        lrequests (list<int>): List of track requests.
        debug (bool): If True, prints debug information.

    Returns:
        dict: Contains the seek sequence, total distance, and average seek length.
    """
    # Ordenar las solicitudes de pistas
    lrequests.sort()
    
    # Separar las solicitudes en dos partes: mayores y menores que la posición inicial
    higher = [req for req in lrequests if req >= arm_position]
    lower = [req for req in lrequests if req < arm_position]

    # Secuencia de servicio: primero las solicitudes mayores, luego circular a las menores
    sequence = higher + lower
    distance = 0
    current_pos = arm_position

    for request in sequence:
        distance += abs(request - current_pos)
        current_pos = request
        if debug:
            print("> ", current_pos, "seeked")

    average = distance / len(lrequests)

    return {
        "sequence": [arm_position] + sequence,
        "distance": distance,
        "average": average,
    }

# Prueba del algoritmo
result = clook(96, [125, 17, 23, 67, 90, 128, 189, 115, 97])
print(f"Secuencia de movimientos: {result['sequence']}")
print(f"Distancia total recorrida: {result['distance']}")
print(f"Promedio de distancias: {result['average']:.2f}")
