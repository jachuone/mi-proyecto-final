def cscan(arm_position, lrequests, debug=False, max_track=200):
    """
    Circular SCAN (CSCAN) implementation.

    Args:
        arm_position (int): Initial position of the arm.
        lrequests (list<int>): List of track requests.
        debug (bool): If True, prints debug information.
        max_track (int): Maximum track number on the disk (default: 200).

    Returns:
        dict: Contains the seek sequence, total distance, and average seek length.
    """
    # Ordenar las solicitudes
    lrequests.sort()
    
    # Dividir solicitudes mayores y menores a la posición actual
    higher = [req for req in lrequests if req >= arm_position]
    lower = [req for req in lrequests if req < arm_position]

    # Secuencia de servicio: atender las mayores, llegar al final, saltar al inicio y atender las menores
    sequence = higher + [max_track] + [0] + lower
    distance = 0
    current_pos = arm_position

    for request in sequence:
        distance += abs(request - current_pos)
        current_pos = request
        if debug:
            print("> ", current_pos, "seeked")

    average = distance / len(lrequests)

    return {
        "sequence": [arm_position] + sequence,
        "distance": distance,
        "average": average,
    }

# Prueba del algoritmo
result = cscan(96, [125, 17, 23, 67, 90, 128, 189, 115, 97])
print(f"Secuencia de movimientos: {result['sequence']}")
print(f"Distancia total recorrida: {result['distance']}")
print(f"Promedio de distancias: {result['average']:.2f}")
