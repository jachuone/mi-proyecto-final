from flask import Flask, request, jsonify
from flask_cors import CORS
from fcfs import fcfs
from sstf import sstf
from scan import scan
from cscan import cscan
from look import look
from clook import clook

app = Flask(__name__)
CORS(app)

@app.route("/", methods=['GET'])
def hello():
    return jsonify({"message": "use /usage to get information"}), 200

@app.route("/usage", methods=['GET'])
def help():
    return jsonify({
        "message": "use FIFO, SSTF, SCAN or CSCAN algorithms",
        "instructions": {
            "endpoint": "/sched",
            "method": "POST",
            "payload": {
                "algorithm": "1:FCFS, 2:SSTF, 3:SCAN, 4:CSCAN, 5:LOOK, 6:CLOOK",
                "tracks": "number of cylinders",
                "arm": "initial position",
                "requests": "list of tracks"
            },
            "payload_example": {
                "algorithm": 1,
                "tracks": 200,
                "arm": 96,
                "requests": [125, 17, 23, 67, 90, 128, 189, 115, 97]
            },
            "description": "This endpoint performs disk scheduling algorithms"
        }
    }), 200

@app.route("/sched", methods=['POST'])
def sched():
    data = request.get_json()
    algorithm = data.get("algorithm")
    tracks = data.get("tracks")
    arm = data.get("arm")
    requests = data.get("requests")
  
    # Diccionario de algoritmos
    algorithms = {
        1: fcfs,
        2: sstf,
        3: scan,
        4: cscan,
        5: look,
        6: clook
    }
  
    # Selección de algoritmo
    selected_algorithm = algorithms.get(algorithm)
  
    if selected_algorithm:
        result = selected_algorithm(arm, requests, debug=True)  # Activa el modo debug si lo necesitas
        return jsonify({"result": result}), 200
    else:
        return jsonify({"error": "Invalid algorithm"}), 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)


