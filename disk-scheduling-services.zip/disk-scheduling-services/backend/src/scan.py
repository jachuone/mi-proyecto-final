def scan(arm_position, lrequests, max_track=200, debug=False):
    """
    Elevator Algorithm (SCAN) implementation

    Args:
        arm_position (int): Initial position of the arm.
        lrequests (list<int>): List of track requests.
        max_track (int): Maximum track number (default: 200).
        debug (bool): If True, prints debug information.

    Returns:
        dict: Contains the seek sequence, total distance, and average seek length.
    """
    # Ordenar las solicitudes
    lrequests.sort()

    # Dividir las solicitudes mayores y menores a la posición actual
    higher = [req for req in lrequests if req >= arm_position]
    lower = [req for req in lrequests if req < arm_position][::-1]  # Invertir las menores para procesarlas en orden descendente

    # Secuencia de servicio: atender las mayores, llegar al final, y luego las menores
    sequence = higher + [max_track] + lower
    distance = 0
    current_pos = arm_position

    # Calcular la distancia total recorrida
    for request in sequence:
        distance += abs(request - current_pos)
        current_pos = request
        if debug:
            print("> ", current_pos, "seeked")

    average = distance / len(lrequests)

    return {
        "sequence": [arm_position] + sequence,
        "distance": distance,
        "average": average,
    }


# Prueba del algoritmo
result = scan(96, [125, 17, 23, 67, 90, 128, 189, 115, 97])
print(f"Secuencia de movimientos: {result['sequence']}")
print(f"Distancia total recorrida: {result['distance']}")
print(f"Promedio de distancias: {result['average']:.2f}")
